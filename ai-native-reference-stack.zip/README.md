# AI-Native Reference Stack

This repository documents a real-world exploration of how AI-native tools can be used to design and deploy full systems without traditional developer workflows.

Led by Mike Higgins, Retired Chief Strategist at ExxonMobil IT, this initiative showcases how AI orchestration can empower system thinkers and non-developers alike.

See the `index.md` for a structured site overview.
