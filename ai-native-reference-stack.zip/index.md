# AI-Native Systems Architecture

Welcome to the reference implementation and documentation project for a real-world AI-native system design process...

(Full index content inserted here — abbreviated for brevity)
